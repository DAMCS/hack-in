import random





'''

        Node class:

        Methods:

                        get_value() -> returns the value of the antivirus.

                        get_colour() -> returns the color 'r' or 'b'.

                                        'r'             denotes red.

                                        'b'             denotes blue.

                                        None    if the tile is empty.

                        get_neighbours() -> return [(x, y), ...], the point represents the index in the board



        board - a dictionay contains co-ordinates [(x, y) - tuple] as key and Node Object as value



        free_space - a set consists of co-ordinates which are left to be filled.



        value - the value of the antivirus.



        The function must return a tuple only from free_spaces.



'''



class player:

    def next_move(self, board, free_space, value):

        ''' Your code goes here '''


