Write your bot logic in the source file given.
Upload only the source code to the site.
Wait for us to compile your code and 
	we provide you with a UI simulation.
If there are any issues, please let us know!


Also mail your feedbacks about the event to
hackinpsg2019@gmail.com
